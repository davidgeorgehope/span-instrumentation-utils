package org.davidgeorgehope.tests;

public class TestClass {
        public String getValue() {
            return "testValue";
        }
}
